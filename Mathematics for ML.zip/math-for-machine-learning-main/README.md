# math-for-machine-learning
Statistics and math for machine learning and data science
